
class Keycloak {
  constructor(config) {
    this.authenticated = true;
    this.tokenParsed = { sub: 'test-keycloak-sub-001', preferred_username: 'dr.anna' };
    this.token = 'mock-access-token';
  }
  init() { return Promise.resolve(true); }
  login() { return Promise.resolve(); }
  logout(opts) {
    window.location.href = (opts && opts.redirectUri) || window.location.origin;
    return Promise.resolve();
  }
  updateToken() { return Promise.resolve(true); }
  clearToken() {}
  isTokenExpired() { return false; }
  hasRealmRole() { return true; }
  hasResourceRole() { return true; }
  createLoginUrl() { return '#'; }
  createLogoutUrl() { return '#'; }
}
export default Keycloak;
